from typing import Any
from typing import ClassVar
from typing import Optional

import numpy as np

from evidently.features.generated_features import ApplyColumnGeneratedFeature


class NonLetterCharacterPercentage(ApplyColumnGeneratedFeature):
    display_name_template: ClassVar = "Non Letter Character % for {column_name}"
    column_name: str

    def __init__(self, column_name: str, display_name: Optional[str] = None):
        self.column_name = column_name
        self.display_name = display_name
        super().__init__()

    def apply(self, value: Any):
        """counts share of characters that are not letters or spaces"""
        if value is None or (isinstance(value, float) and np.isnan(value)):
            return 0
        non_letters_num = 0
        for ch in value:
            if not ch.isalpha() and ch != " ":
                non_letters_num += 1
        return 100 * non_letters_num / len(value)
