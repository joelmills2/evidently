import{R as a,r as t}from"./vendor-Bhc2M4pH.js";const s=a.createContext(null),o=()=>t.useContext(s);export{s as D,o as u};
